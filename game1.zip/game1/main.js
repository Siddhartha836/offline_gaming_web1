document.addEventListener('DOMContentLoaded', function() {
  var switcher = document.getElementById('themeSwitcher');
  if (switcher) {
    switcher.addEventListener('click', function() {
      document.body.classList.toggle('light-mode');
      this.innerHTML = document.body.classList.contains('light-mode') ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    });
  }
});

function revealOnScroll() {
  const animatedCards = document.querySelectorAll('.animated-card');
  const animatedSections = document.querySelectorAll('.animated-section, .section');
  const triggerBottom = window.innerHeight * 0.85;
  animatedCards.forEach(card => {
    const cardTop = card.getBoundingClientRect().top;
    if (cardTop < triggerBottom) {
      card.classList.add('visible');
    }
  });
  animatedSections.forEach(section => {
    const sectionTop = section.getBoundingClientRect().top;
    if (sectionTop < triggerBottom) {
      section.classList.add('visible');
    }
  });
}
window.addEventListener('scroll', revealOnScroll);
window.addEventListener('DOMContentLoaded', revealOnScroll);

// Tab switching for Monster Hunter section
const tabBtns = document.querySelectorAll('.tab-btn');
const stackImg = document.querySelector('.stack-img');
tabBtns.forEach(btn => {
  btn.addEventListener('click', function() {
    tabBtns.forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    if (stackImg) {
      if (this.dataset.tab === 'hunters') stackImg.src = 'games/assets/monster1.png';
      if (this.dataset.tab === 'monsters') stackImg.src = 'games/assets/monster2.png';
      if (this.dataset.tab === 'technology') stackImg.src = 'games/assets/monster3.png';
    }
  });
});
// FAQ expand/collapse
const faqItems = document.querySelectorAll('.faq-item');
faqItems.forEach(item => {
  const question = item.querySelector('.faq-question');
  const answer = item.querySelector('.faq-answer');
  const toggle = item.querySelector('.faq-toggle');
  question.addEventListener('click', function() {
    const isOpen = answer.style.display === 'block';
    faqItems.forEach(i => {
      i.classList.remove('active');
      i.querySelector('.faq-answer').style.display = 'none';
      i.querySelector('.faq-toggle').textContent = '+';
    });
    if (!isOpen) {
      answer.style.display = 'block';
      item.classList.add('active');
      toggle.textContent = '-';
    }
  });
});
// Animate team members on scroll
function revealTeamOnScroll() {
  const teamMembers = document.querySelectorAll('.team-member');
  const triggerBottom = window.innerHeight * 0.85;
  teamMembers.forEach(member => {
    const memberTop = member.getBoundingClientRect().top;
    if (memberTop < triggerBottom) {
      member.classList.add('visible');
    }
  });
}
window.addEventListener('scroll', revealTeamOnScroll);
window.addEventListener('DOMContentLoaded', revealTeamOnScroll);