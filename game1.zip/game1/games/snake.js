document.addEventListener('DOMContentLoaded', function () {
  const canvas = document.getElementById('snake-canvas');
  const ctx = canvas.getContext('2d');
  const box = 20;
  let snake = [{ x: 7, y: 7 }];
  let direction = 'RIGHT';
  let food = { x: Math.floor(Math.random() * 16), y: Math.floor(Math.random() * 16) };
  let score = 0;
  let gameInterval;
  const statusDiv = document.getElementById('snake-status');
  const resetBtn = document.getElementById('reset-btn');

  function drawBoard() {
    ctx.fillStyle = '#181c2f';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    // Draw snake
    for (let i = 0; i < snake.length; i++) {
      ctx.fillStyle = i === 0 ? '#d4ff00' : '#00ffe7';
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 10;
      ctx.fillRect(snake[i].x * box, snake[i].y * box, box, box);
      ctx.shadowBlur = 0;
    }
    // Draw food
    ctx.fillStyle = '#ff00c8';
    ctx.shadowColor = '#ff00c8';
    ctx.shadowBlur = 10;
    ctx.fillRect(food.x * box, food.y * box, box, box);
    ctx.shadowBlur = 0;
  }

  function moveSnake() {
    let head = { ...snake[0] };
    if (direction === 'LEFT') head.x--;
    if (direction === 'UP') head.y--;
    if (direction === 'RIGHT') head.x++;
    if (direction === 'DOWN') head.y++;

    // Wall collision
    if (head.x < 0 || head.x > 15 || head.y < 0 || head.y > 15) {
      endGame('Game Over!');
      return;
    }
    // Self collision
    for (let i = 0; i < snake.length; i++) {
      if (head.x === snake[i].x && head.y === snake[i].y) {
        endGame('Game Over!');
        return;
      }
    }
    // Food collision
    if (head.x === food.x && head.y === food.y) {
      snake.unshift(head);
      score++;
      placeFood();
    } else {
      snake.unshift(head);
      snake.pop();
    }
    drawBoard();
    statusDiv.textContent = `Score: ${score}`;
  }

  function placeFood() {
    food = { x: Math.floor(Math.random() * 16), y: Math.floor(Math.random() * 16) };
    // Avoid placing food on the snake
    while (snake.some(segment => segment.x === food.x && segment.y === food.y)) {
      food = { x: Math.floor(Math.random() * 16), y: Math.floor(Math.random() * 16) };
    }
  }

  function endGame(message) {
    clearInterval(gameInterval);
    statusDiv.textContent = `${message} Final Score: ${score}`;
    ctx.font = 'bold 32px Orbitron, Arial';
    ctx.fillStyle = '#d4ff00';
    ctx.textAlign = 'center';
    ctx.fillText(message, canvas.width / 2, canvas.height / 2);
    saveScore('Snake', score); // <-- Add this line
  }

  function startGame() {
    snake = [{ x: 7, y: 7 }];
    direction = 'RIGHT';
    score = 0;
    placeFood();
    drawBoard();
    statusDiv.textContent = 'Score: 0';
    clearInterval(gameInterval);
    gameInterval = setInterval(moveSnake, 120);
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowLeft' && direction !== 'RIGHT') direction = 'LEFT';
    if (e.key === 'ArrowUp' && direction !== 'DOWN') direction = 'UP';
    if (e.key === 'ArrowRight' && direction !== 'LEFT') direction = 'RIGHT';
    if (e.key === 'ArrowDown' && direction !== 'UP') direction = 'DOWN';
  });

  // Touch controls for mobile
  let touchStartX = 0, touchStartY = 0;
  canvas.addEventListener('touchstart', function (e) {
    const touch = e.touches[0];
    touchStartX = touch.clientX;
    touchStartY = touch.clientY;
  });
  canvas.addEventListener('touchend', function (e) {
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStartX;
    const dy = touch.clientY - touchStartY;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dx > 0 && direction !== 'LEFT') direction = 'RIGHT';
      else if (dx < 0 && direction !== 'RIGHT') direction = 'LEFT';
    } else {
      if (dy > 0 && direction !== 'UP') direction = 'DOWN';
      else if (dy < 0 && direction !== 'DOWN') direction = 'UP';
    }
  });

  resetBtn.addEventListener('click', startGame);
  startGame();
});


function saveScore(game, score) {
  const scores = JSON.parse(localStorage.getItem('playzone_leaderboard') || '[]');
  scores.push({
    game: game,
    score: score,
    date: new Date().toLocaleString()
  });
  localStorage.setItem('playzone_leaderboard', JSON.stringify(scores));
}