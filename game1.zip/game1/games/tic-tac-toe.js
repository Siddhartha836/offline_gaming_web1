document.addEventListener('DOMContentLoaded',function(){
  const board=document.getElementById('tic-tac-toe-board');
  const status=document.getElementById('ttt-status');
  const reset=document.getElementById('ttt-reset');
  let cells=[];
  let currentPlayer='X';
  let gameActive=true;
  let gameState=["","","","","","","","",""];
  function renderBoard(){
    board.innerHTML='';
    for(let i=0;i<9;i++){
      const cell=document.createElement('button');
      cell.className='ttt-cell';
      cell.setAttribute('data-index',i);
      cell.textContent=gameState[i];
      cell.addEventListener('click',()=>handleCellClick(i));
      cells[i]=cell;
      board.appendChild(cell);
    }
  }
  function handleCellClick(i){
    if(!gameActive||gameState[i])return;
    gameState[i]=currentPlayer;
    renderBoard();
    if(checkWin()){
      status.textContent=`Player ${currentPlayer} wins!`;
      gameActive=false;
      return;
    }
    if(gameState.every(cell=>cell)){
      status.textContent='Draw!';
      gameActive=false;
      return;
    }
    currentPlayer=currentPlayer==='X'?'O':'X';
    status.textContent=`Player ${currentPlayer}'s turn`;
  }
  function checkWin(){
    const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    return wins.some(comb=>comb.every(idx=>gameState[idx]===currentPlayer));
  }
  function resetGame(){
    gameState=["","","","","","","","",""];
    currentPlayer='X';
    gameActive=true;
    status.textContent=`Player ${currentPlayer}'s turn`;
    renderBoard();
  }
  reset.addEventListener('click',resetGame);
  resetGame();
});