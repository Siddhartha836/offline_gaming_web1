document.addEventListener('DOMContentLoaded',function(){
  const board=document.getElementById('memory-game-board');
  const status=document.getElementById('mg-status');
  const reset=document.getElementById('mg-reset');
  let icons=['🍕','🍔','🍟','🌭','🍿','🥨','🍩','🍦'];
  let cells=[];
  let first=null,second=null,lock=false,matches=0;
  function shuffle(arr){for(let i=arr.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]];}}
  function renderBoard(){
    let pairs=icons.concat(icons);
    shuffle(pairs);
    board.innerHTML='';
    cells=[];
    for(let i=0;i<16;i++){
      const cell=document.createElement('div');
      cell.className='mg-cell';
      cell.setAttribute('data-index',i);
      cell.textContent='?';
      cell.addEventListener('click',()=>handleCellClick(i));
      cells[i]={el:cell,icon:pairs[i],flipped:false,matched:false};
      board.appendChild(cell);
    }
    first=second=null;lock=false;matches=0;
    status.textContent='Find all pairs!';
  }
  function handleCellClick(i){
    if(lock||cells[i].flipped||cells[i].matched)return;
    cells[i].flipped=true;
    cells[i].el.textContent=cells[i].icon;
    cells[i].el.classList.add('flipped');
    if(first===null){first=i;return;}
    second=i;lock=true;
    setTimeout(()=>{
      if(cells[first].icon===cells[second].icon){
        cells[first].matched=cells[second].matched=true;
        cells[first].el.classList.add('matched');
        cells[second].el.classList.add('matched');
        matches++;
        if(matches===8){status.textContent='You win!';}
      }else{
        cells[first].flipped=cells[second].flipped=false;
        cells[first].el.textContent='?';
        cells[second].el.textContent='?';
        cells[first].el.classList.remove('flipped');
        cells[second].el.classList.remove('flipped');
      }
      first=second=null;lock=false;
    },800);
  }
  reset.addEventListener('click',renderBoard);
  renderBoard();
});