document.addEventListener('DOMContentLoaded', function () {
  const canvas = document.getElementById('space-shooter-canvas');
  const ctx = canvas.getContext('2d');
  const statusDiv = document.getElementById('ss-status');
  const restartBtn = document.getElementById('restart-btn');
  const width = canvas.width;
  const height = canvas.height;

  // Player
  let player = { x: width / 2 - 20, y: height - 40, w: 40, h: 20, color: '#00ffe7' };
  let bullets = [];
  let enemies = [];
  let score = 0;
  let gameOver = false;
  let gameInterval;

  function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.shadowColor = '#00ffe7';
    ctx.shadowBlur = 10;
    ctx.fillRect(player.x, player.y, player.w, player.h);
    ctx.shadowBlur = 0;
  }

  function drawBullets() {
    ctx.fillStyle = '#d4ff00';
    bullets.forEach(b => {
      ctx.fillRect(b.x, b.y, b.w, b.h);
    });
  }

  function drawEnemies() {
    enemies.forEach(e => {
      ctx.fillStyle = '#ff00c8';
      ctx.shadowColor = '#ff00c8';
      ctx.shadowBlur = 10;
      ctx.fillRect(e.x, e.y, e.w, e.h);
      ctx.shadowBlur = 0;
    });
  }

  function draw() {
    ctx.clearRect(0, 0, width, height);
    drawPlayer();
    drawBullets();
    drawEnemies();
    statusDiv.textContent = `Score: ${score}`;
  }

  function moveBullets() {
    bullets.forEach(b => b.y -= 8);
    bullets = bullets.filter(b => b.y + b.h > 0);
  }

  function moveEnemies() {
    enemies.forEach(e => e.y += 2);
    enemies = enemies.filter(e => e.y < height);
  }

  function checkCollisions() {
    // Bullet hits enemy
    bullets.forEach((b, bi) => {
      enemies.forEach((e, ei) => {
        if (
          b.x < e.x + e.w &&
          b.x + b.w > e.x &&
          b.y < e.y + e.h &&
          b.y + b.h > e.y
        ) {
          bullets.splice(bi, 1);
          enemies.splice(ei, 1);
          score++;
        }
      });
    });
    // Enemy hits player
    enemies.forEach(e => {
      if (
        player.x < e.x + e.w &&
        player.x + player.w > e.x &&
        player.y < e.y + e.h &&
        player.y + player.h > e.y
      ) {
        endGame();
      }
    });
  }

  function spawnEnemy() {
    const w = 40, h = 20;
    const x = Math.random() * (width - w);
    enemies.push({ x, y: -h, w, h });
  }

  function endGame() {
    clearInterval(gameInterval);
    gameOver = true;
    statusDiv.textContent = `Game Over! Final Score: ${score}`;
    ctx.font = 'bold 32px Orbitron, Arial';
    ctx.fillStyle = '#ff00c8';
    ctx.textAlign = 'center';
    ctx.fillText('Game Over!', width / 2, height / 2);
  }

  function gameLoop() {
    if (Math.random() < 0.03) spawnEnemy();
    moveBullets();
    moveEnemies();
    checkCollisions();
    draw();
  }

  function startGame() {
    player = { x: width / 2 - 20, y: height - 40, w: 40, h: 20, color: '#00ffe7' };
    bullets = [];
    enemies = [];
    score = 0;
    gameOver = false;
    statusDiv.textContent = 'Score: 0';
    draw();
    clearInterval(gameInterval);
    gameInterval = setInterval(gameLoop, 30);
  }

  document.addEventListener('keydown', function (e) {
    if (gameOver) return;
    if (e.key === 'ArrowLeft' && player.x > 0) player.x -= 20;
    if (e.key === 'ArrowRight' && player.x < width - player.w) player.x += 20;
    if (e.key === ' ' || e.key === 'ArrowUp') {
      bullets.push({ x: player.x + player.w / 2 - 4, y: player.y, w: 8, h: 16 });
    }
  });

  // Touch controls for mobile
  let touchStartX = 0;
  canvas.addEventListener('touchstart', function (e) {
    touchStartX = e.touches[0].clientX;
  });
  canvas.addEventListener('touchend', function (e) {
    const dx = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(dx) > 30) {
      if (dx > 0 && player.x < width - player.w) player.x += 40;
      else if (dx < 0 && player.x > 0) player.x -= 40;
    } else {
      // Tap to shoot
      bullets.push({ x: player.x + player.w / 2 - 4, y: player.y, w: 8, h: 16 });
    }
  });

  restartBtn.addEventListener('click', startGame);
  startGame();
});